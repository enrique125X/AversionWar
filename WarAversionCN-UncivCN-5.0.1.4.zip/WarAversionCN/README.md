# WarAversionCN (UncivCN 5.0.1.4)

Sistema de Aversión a la Guerra optimizado para **UncivCN 5.0.1.4**.

## Reglas y umbrales
- Turno en guerra: `+1` · Turno en paz: `-1`
- Unidad militar perdida en combate: `+2` · Unidad enemiga eliminada: `-1`
- Ciudad conquistada: `-15`
- Límite máximo (`Variables.json`): `120` (clamping nativo `[0, 120]`)
- Divisor de escala: `-2%` por cada `6` puntos (equivalente a `-1.00%` por cada 3)
- Umbrales: **T1=24** (Oro), **T2=48** (Alimento), **T3=72** (Producción + Rebeldes nativos), **T4=96** (Ciencia, Cultura y Fuerza de Combate vía `LuaModifyCombatStrength` O(1)).

## Instalación
Copia esta carpeta dentro de `mods/` de UncivCN 5.0.1.4 y actívala al crear partida.
